<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro da Agenda</title>
    
    
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    

    <style>
        body {
            background-color:rgb(65, 219, 103);
        }
        .container {
            max-width: 500px;
            margin-top: 50px;
            padding: 30px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .form-group label {
            font-weight: bold;
        }
        .btn-primary {
            width: 100%;
            font-size: 18px;
        }
        .text-center {
            margin-top: 15px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Cadastro da Agenda</h2>
    
    <form action="../Controller/contatoController.php" method="POST">
        <div class="form-group">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <textarea name="descricao" id="descricao" class="form-control" required></textarea>
        </div>

        <div class="form-group">
            <label for="data_inicio">Data e Hora de Início:</label>
            <input type="datetime-local" name="data_inicio" id="data_inicio" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="data_termino">Data e Hora de Término:</label>
            <input type="datetime-local" name="data_termino" id="data_termino" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="status">Status:</label>
            <select name="status" id="status" class="form-control">
                <option value="pendente">Pendente</option>
                <option value="concluído">Concluído</option>
                <option value="cancelado">Cancelado</option>
            </select>
        </div>

        <div class="form-group">
            <label for="senha">Senha:</label>
            <input type="password" name="senha" id="senha" class="form-control" required>
        </div>

        <button type="submit" name="cadastrar" class="btn btn-primary">Cadastrar</button>
    </form>

    <p class="text-center">Já tem uma conta? <a href="login.php">Faça login</a></p>
</div>

<!-- Bootstrap JS -->
<script src="bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>
