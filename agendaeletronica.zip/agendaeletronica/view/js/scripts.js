
function cadastrarContato() {
    let dados = {
        'email': $('#email').val(),
        'senha': $('#senha').val(),
        'nome': $('#nome').val(),
        'sobrenome': $('#sobrenome').val(),
        'cadastrar': $('#cadastrar').val()
    };

    carregarModalLoading(); 

    $.ajax({
        url: '../controller/contatoController.php',
        type: 'POST',
        data: dados,
        dataType: 'json',  
        success: function(data) {
            setTimeout(function() {
                esconderModalLoading();
                $('#status').text(data.mensagem);

                if (data.codigo == 1) {
                    $('#status').css({ "color": "#f1c40f" });

                    setTimeout(function() {
                        window.location.href = "index.php";
                    }, 2000);
                } else {
                    $(data.campo).focus();
                    $('#status').css({ "color": "#ff6f65" });
                }
            }, 1000);
        },
        
    });
}





function carregarModalLoading() {
    $('#modalLoading').css({
        "display": "block"
    });
}
function esconderModalLoading() {
    $('#modalLoading').css({
        "display": "none"

    
    });


}