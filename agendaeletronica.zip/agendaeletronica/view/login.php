<?php
session_start();
$mensagem = isset($_SESSION['mensagem_erro']) ? $_SESSION['mensagem_erro'] : "";
unset($_SESSION['mensagem_erro']); // Remove a mensagem após exibir
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    
    <style>
        body {
            background-color: #f4f4f4;
        }
        .container {
            max-width: 400px;
            margin-top: 50px;
            padding: 30px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .alert {
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Login</h2>

    <?php if (!empty($mensagem)) { ?>
        <div class="alert alert-danger"><?php echo $mensagem; ?></div>
    <?php } ?>

    <form action="../Controller/loginController.php" method="POST">
        <div class="form-group">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="senha">Senha:</label>
            <input type="password" name="senha" id="senha" class="form-control" required>
        </div>

        <button type="submit" name="login" class="btn btn-primary btn-block">Entrar</button>
    </form>

    <p class="text-center">Não tem uma conta? <a href="cadastro.php">Cadastre-se</a></p>
</div>

</body>
</html>
