<?php
session_start();
include_once "../model/atividadeDAO.php";

$dao = new AtividadeDAO();
$atividades = $dao->listarAtividadesPorUsuario($_SESSION['usuario_id']);

$dataSelecionada = isset($_GET['data']) ? $_GET['data'] : date('Y-m-d');

$eventos = [];
foreach ($atividades as $atividade) {
    if (strpos($atividade['data_inicio'], $dataSelecionada) !== false) {
        $eventos[] = [
            "id" => $atividade['id'],
            "title" => $atividade['titulo'],
            "description" => $atividade['descricao']
        ];
    }
}

header('Content-Type: application/json');
echo json_encode($eventos);
?>
