<?php
session_start();
include_once "../model/atividadeDAO.php";

$dao = new AtividadeDAO();
$usuario_id = $_SESSION['usuario_id'];
$mes = isset($_GET['mes']) ? $_GET['mes'] : date('m');
$ano = isset($_GET['ano']) ? $_GET['ano'] : date('Y');

// Função para criar o calendário
function gerarCalendario($mes, $ano, $atividades) {
    $diasNoMes = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);
    $primeiroDia = date('N', strtotime("$ano-$mes-01"));

    echo "<table class='table table-bordered'>";
    echo "<tr><th>Dom</th><th>Seg</th><th>Ter</th><th>Qua</th><th>Qui</th><th>Sex</th><th>Sáb</th></tr>";
    echo "<tr>";

    for ($i = 1; $i < $primeiroDia; $i++) {
        echo "<td></td>";
    }

    for ($dia = 1; $dia <= $diasNoMes; $dia++) {
        $dataAtual = "$ano-$mes-" . str_pad($dia, 2, '0', STR_PAD_LEFT);
        $classe = isset($atividades[$dataAtual]) ? "bg-success text-white" : "";
        echo "<td class='$classe' onclick='verCompromissos(\"$dataAtual\")'>$dia</td>";

        if (($dia + $primeiroDia - 1) % 7 == 0) {
            echo "</tr><tr>";
        }
    }

    echo "</tr>";
    echo "</table>";
}
$atividades = [];
foreach ($dao->listarAtividadesPorUsuario($usuario_id) as $atividade) {
    $data = explode(" ", $atividade['data_inicio'])[0];
    $atividades[$data][] = $atividade;
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Calendário</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
<div class="container mt-4">
    <h2>Calendário de Compromissos</h2>
    <button onclick="mudarMes(-1)" class="btn btn-primary">← Anterior</button>
    <button onclick="mudarMes(1)" class="btn btn-primary">Próximo →</button>

    <h3><?php echo date('F Y', strtotime("$ano-$mes-01")); ?></h3>

    <?php gerarCalendario($mes, $ano, $atividades); ?>

    <h3>Compromissos do Dia</h3>
    <ul id="lista-compromissos" class="list-group"></ul>
</div>

<script>
function mudarMes(direcao) {
    var mesAtual = <?php echo $mes; ?>;
    var anoAtual = <?php echo $ano; ?>;
    var novoMes = mesAtual + direcao;
    var novoAno = anoAtual;

    if (novoMes < 1) {
        novoMes = 12;
        novoAno--;
    } else if (novoMes > 12) {
        novoMes = 1;
        novoAno++;
    }

    window.location.href = "calendario.php?mes=" + novoMes + "&ano=" + novoAno;
}

function verCompromissos(data) {
    $.get("get_atividades.php?data=" + data, function(response) {
        $("#lista-compromissos").html("");
        if (response.length > 0) {
            response.forEach(event => {
                $("#lista-compromissos").append(`<li class='list-group-item'>
                    <strong>${event.title}</strong> - ${event.description}
                    <button class='btn btn-danger btn-sm' onclick='excluirCompromisso(${event.id})'>Excluir</button>
                </li>`);
            });
        } else {
            $("#lista-compromissos").html("<li class='list-group-item'>Nenhum compromisso encontrado.</li>");
        }
    }, "json");
}

function excluirCompromisso(id) {
    if (confirm("Deseja excluir este compromisso?")) {
        $.get("../Controller/atividadeController.php?excluir=" + id, function() {
            alert("Compromisso excluído!");
            location.reload();
        });
    }
}
</script>

</body>
</html>
