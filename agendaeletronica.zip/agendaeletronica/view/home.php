<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

include_once "../model/atividadeDAO.php";
$dao = new AtividadeDAO();
$atividades = $dao->listarAtividadesPorUsuario($_SESSION['usuario_id']);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha Agenda</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.8.0/css/pikaday.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.8.0/pikaday.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>

<div class="container mt-4">
    <h2>Bem-vindo, <?php echo htmlspecialchars($_SESSION['usuario_nome']); ?>!</h2>
    <a href="logout.php" class="btn btn-danger">Sair</a>

    <h3 class="mt-4">Selecione uma Data</h3>
    <input type="text" id="datepicker" class="form-control" placeholder="Escolha um dia">

    <h3 class="mt-4">Compromissos do Dia</h3>
    <ul id="lista-compromissos" class="list-group">
        
    </ul>

    <h3 class="mt-4">Marcar Novo Compromisso</h3>
    <form id="form-compromisso">
        <input type="hidden" id="dataSelecionada" name="data">
        <input type="hidden" id="id" name="id">
        <div class="mb-3">
            <label for="titulo" class="form-label">Título</label>
            <input type="text" class="form-control" id="titulo" name="titulo" required>
        </div>
        <div class="mb-3">
            <label for="descricao" class="form-label">Descrição</label>
            <textarea class="form-control" id="descricao" name="descricao" required></textarea>
        </div>
        <div class="mb-3">
            <label for="hora" class="form-label">Horário</label>
            <input type="time" class="form-control" id="hora" name="hora" required>
        </div>
        <button type="submit" class="btn btn-success">Salvar Compromisso</button>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var picker = new Pikaday({
        field: document.getElementById('datepicker'),
        format: 'YYYY-MM-DD',
        onSelect: function(date) {
            $('#dataSelecionada').val(this.getMoment().format('YYYY-MM-DD'));
            carregarCompromissos(this.getMoment().format('YYYY-MM-DD'));
        }
    });

    function carregarCompromissos(data) {
        $("#lista-compromissos").html("<li class='list-group-item'>Carregando...</li>");
        $.get("../view/get_atividades.php?data=" + data, function(response) {
            $("#lista-compromissos").html("");
            if (response.length > 0) {
                response.forEach(event => {
                    $("#lista-compromissos").append(`<li class='list-group-item'>
                        <strong>${event.title}</strong><br>
                        ${event.description} - ${event.start.split(" ")[1]}
                        <button class='btn btn-primary btn-sm' onclick='editarCompromisso(${JSON.stringify(event)})'>Editar</button>
                        <button class='btn btn-danger btn-sm' onclick='excluirCompromisso(${event.id})'>Excluir</button>
                    </li>`);
                });
            } else {
                $("#lista-compromissos").html("<li class='list-group-item'>Nenhum compromisso encontrado.</li>");
            }
        }, "json");
    }

    function editarCompromisso(event) {
        $('#id').val(event.id);
        $('#titulo').val(event.title);
        $('#descricao').val(event.description);
        $('#hora').val(event.start.split(" ")[1]);
        $('#dataSelecionada').val(event.start.split(" ")[0]);
    }

    function excluirCompromisso(id) {
        if (confirm("Deseja realmente excluir este compromisso?")) {
            $.get("../Controller/atividadeController.php?excluir=" + id, function(response) {
                if (response.sucesso) {
                    carregarCompromissos($('#dataSelecionada').val());
                } else {
                    alert("Erro ao excluir compromisso!");
                }
            }, "json");
        }
    }

    $("#form-compromisso").submit(function(e) {
        e.preventDefault();
        var dados = $(this).serialize();
        $.post("../Controller/atividadeController.php", dados, function(response) {
            if (response.sucesso) {
                carregarCompromissos($('#dataSelecionada').val());
                alert("Compromisso salvo com sucesso!");
            } else {
                alert("Erro ao adicionar compromisso!");
            }
        }, "json");
    });
});
</script>

</body>
</html>
