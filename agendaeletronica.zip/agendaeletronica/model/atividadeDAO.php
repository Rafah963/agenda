<?php
include_once "conexaoDB.php";

class AtividadeDAO {
    public function listarAtividadesPorUsuario($usuario_id) {
        $conexao = (new conexaoDB())->abrirConexao();
        $query = "SELECT * FROM atividades WHERE usuario_id = ?";
        
        $stmt = $conexao->prepare($query);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        
        $atividades = [];
        while ($row = $resultado->fetch_assoc()) {
            $atividades[] = $row;
        }

        $stmt->close();
        (new conexaoDB())->fecharConexaoDB($conexao);
        return $atividades;
    }

    public function atualizarAtividade($atividade) {
        $conexao = (new conexaoDB())->abrirConexao();
        $query = "UPDATE atividades SET titulo = ?, descricao = ?, data_inicio = ?, data_termino = ? WHERE id = ? AND usuario_id = ?";
        
        $stmt = $conexao->prepare($query);
        $stmt->bind_param("ssssii", 
            $atividade->titulo, 
            $atividade->descricao, 
            $atividade->data_inicio, 
            $atividade->data_termino,
            $atividade->id,
            $atividade->usuario_id
        );
        
        $sucesso = $stmt->execute();
        $stmt->close();
        (new conexaoDB())->fecharConexaoDB($conexao);
        
        return $sucesso;
    }
}
?>
