<?php
class ConexaoDB {
    public function abrirConexao() {
        $banco = "agenda";
        $servidor = "localhost";
        $usuario = "root";
        $senha = "";

        $conexao = new mysqli($servidor, $usuario, $senha, $banco);
        if ($conexao->connect_error) {
            die("Erro na conexão: " . $conexao->connect_error);
        }
        return $conexao;
    }

    public function fecharConexaoDB($conexao) {
        $conexao->close();
    }
}
?>
