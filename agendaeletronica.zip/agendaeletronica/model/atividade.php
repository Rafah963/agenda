<?php
class Atividade {
    public $id;
    public $usuario_id;
    public $titulo;
    public $descricao;
    public $data_inicio;
    public $data_termino;
    public $status;
}
?>
