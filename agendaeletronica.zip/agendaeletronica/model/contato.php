<?php
class Contato {
    public $id;
    public $nome;
    public $descricao;
    public $data_inicio;
    public $data_termino;
    public $status;
    public $senha;
}
?>
