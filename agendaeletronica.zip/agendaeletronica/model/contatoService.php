<?php
class ContatoService {
    public function cadastrarContatoService($contato) {
        $campo = $this->verificarCampo($contato->nome, "nome");
        if (!$campo['sucesso']) return $campo;

        $campo = $this->verificarCampo($contato->descricao, "descricao");
        if (!$campo['sucesso']) return $campo;

        $campo = $this->verificarCampo($contato->data_inicio, "data_inicio");
        if (!$campo['sucesso']) return $campo;

        $campo = $this->verificarCampo($contato->data_termino, "data_termino");
        if (!$campo['sucesso']) return $campo;

        $campo = $this->verificarCampo($contato->status, "status");
        if (!$campo['sucesso']) return $campo;

        $contato->senha = $this->criptografiaSHA256($contato->senha);

        return array(
            'mensagem' => 'Cadastro realizado com sucesso!',
            'sucesso' => true
        );
    }

    private function criptografiaSHA256($senhaInformada) {
        $salt = hash('sha256', "agenda");
        return hash('sha256', $senhaInformada . $salt);
    }

    private function verificarCampo($valorCampo, $nomeCampo) {
        if (empty($valorCampo)) {
            return array(
                'mensagem' => "Preencha o campo $nomeCampo",
                'campo' => "#$nomeCampo",
                'sucesso' => false
            );
        }

        return array('sucesso' => true);
    }
}
?>
