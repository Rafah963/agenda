<?php
include_once "conexaoDB.php"; 

class ContatoDAO {
    public function salvarContato($contato) {
        $conexao = (new ConexaoDB())->abrirConexao(); 
        
        $query = "INSERT INTO contatos (nome, descricao, data_inicio, data_termino, status, senha) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conexao->prepare($query);
        $stmt->bind_param("ssssss", $contato->nome, $contato->descricao, $contato->data_inicio, $contato->data_termino, $contato->status, $contato->senha);
        $stmt->execute();
        $stmt->close();

        (new ConexaoDB())->fecharConexaoDB($conexao);
        return array('mensagem' => 'Contato salvo com sucesso!', 'sucesso' => true);
    }
}
?>
