<?php
header("Location: View/home.php");
// Ao entrar na página (site), é redirecionado para Home